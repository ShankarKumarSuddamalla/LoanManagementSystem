package com.tcs.loanms.exceptions;

import java.time.LocalDateTime;

public class ErrorResponse {
	private String error;
	private String message;
	private LocalDateTime timestamp;
	
	public ErrorResponse(String error, String message) {
		super();
		this.error = error;
		this.message = message;
		this.timestamp = timestamp.now();
	}

	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	
}
