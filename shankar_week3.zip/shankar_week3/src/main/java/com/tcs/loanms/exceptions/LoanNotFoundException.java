package com.tcs.loanms.exceptions;

public class LoanNotFoundException extends RuntimeException{

	public LoanNotFoundException(String msg) {
		super(msg);
	}

}
