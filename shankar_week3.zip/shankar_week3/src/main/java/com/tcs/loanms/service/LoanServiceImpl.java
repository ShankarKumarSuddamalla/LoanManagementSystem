package com.tcs.loanms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.loanms.entity.Loan;
import com.tcs.loanms.exceptions.DuplicateLoanApplicationException;
import com.tcs.loanms.exceptions.InvalidLoanAmountException;
import com.tcs.loanms.exceptions.LoanNotFoundException;
import com.tcs.loanms.repositories.LoanRepository;

@Service
public class LoanServiceImpl implements LoanService {

	private LoanRepository loanRepo;

	@Autowired
	public LoanServiceImpl(LoanRepository loanRepo) {
		super();
		this.loanRepo = loanRepo;
	}

	@Override
	public List<Loan> viewAllLoans() {
		// TODO Auto-generated method stub
		return loanRepo.viewAllLoans();
	}

	@Override
	public Loan getLoanByLoanId(Long id) {
		// TODO Auto-generated method stubs
		return loanRepo.getLoanByLoanId(id);
	}

	@Override
	public Loan createNewLoan(Loan loan) {
		// TODO Auto-generated method stub
		if (loan.getLoanAmount() <= 0 || loan.getLoanAmount() >= 5000000) {
			throw new InvalidLoanAmountException("Loan Amount must be between 0 and 5000000");
		}
		if (loanRepo.updateLoanStatusByLoanId(loan.getApplicantName())) {
			throw new DuplicateLoanApplicationException("User already exists with the loanStatus Pending");
		}
		loan.setLoanStatus("PENDING");
		return loanRepo.saveLoan(loan);
	}

	@Override
	public Loan updateLoanByLoanId(Long id, String status) {
		// TODO Auto-generated method stubs
		Loan loan = getLoanByLoanId(id);
		loan.setLoanStatus(status);
		return loan;
	}

}
