package com.tcs.loanms.service;

import java.util.List;
import java.util.Optional;

import com.tcs.loanms.entity.Loan;

public interface LoanService {
	public List<Loan> viewAllLoans();
	public Loan getLoanByLoanId(Long id);
	public Loan createNewLoan(Loan loan);
	public Loan updateLoanByLoanId(Long id,String status);
}
