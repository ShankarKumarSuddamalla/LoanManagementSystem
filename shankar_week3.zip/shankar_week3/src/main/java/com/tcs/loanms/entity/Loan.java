package com.tcs.loanms.entity;

public class Loan {
	private Long loanId;
	private String applicantName;
	private String loanStatus;
	private double loanAmount;
	
	public Loan(Long loanId, String applicantName, String loanStatus, double loanAmount) {
		super();
		this.loanId = loanId;
		this.applicantName = applicantName;
		this.loanStatus = loanStatus;
		this.loanAmount = loanAmount;
	}

	public Long getLoanId() {
		return loanId;
	}

	public void setLoanId(Long loanId) {
		this.loanId = loanId;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getLoanStatus() {
		return loanStatus;
	}

	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	
	
}
