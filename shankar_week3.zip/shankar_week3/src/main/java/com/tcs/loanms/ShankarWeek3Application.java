package com.tcs.loanms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShankarWeek3Application {

	public static void main(String[] args) {
		SpringApplication.run(ShankarWeek3Application.class, args);
	}

}
