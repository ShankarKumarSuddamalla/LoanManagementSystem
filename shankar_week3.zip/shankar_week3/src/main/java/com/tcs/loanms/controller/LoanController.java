package com.tcs.loanms.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.loanms.entity.Loan;
import com.tcs.loanms.service.LoanServiceImpl;

@RestController
@RequestMapping("/loans")
public class LoanController {
	private LoanServiceImpl loanService;
	
	@Autowired
	public LoanController(LoanServiceImpl loanService) {
		this.loanService=loanService;
	}
	
	@PostMapping
	public ResponseEntity<Loan> createNewLoan(@RequestBody Loan loan){
		return new ResponseEntity(loanService.createNewLoan(loan),HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<Loan>> viewAllLoans(){
		return ResponseEntity.ok(loanService.viewAllLoans());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Loan> getLoanByLoanId(@PathVariable Long id){
		return  ResponseEntity.ok(loanService.getLoanByLoanId(id));
	}
	
	@PutMapping("/{id}/status")
	public ResponseEntity<Loan> updateLoanByLoanId(@PathVariable Long id,@RequestBody Map<String,String> request){
		
		return ResponseEntity.ok(loanService.updateLoanByLoanId(id,request.get("status")));
	}
	
}
