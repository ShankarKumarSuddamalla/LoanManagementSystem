package com.tcs.loanms.exceptions;

public class InvalidLoanAmountException extends RuntimeException {
	public InvalidLoanAmountException(String msg) {
		super(msg);
	}
}
