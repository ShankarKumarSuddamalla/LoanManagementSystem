package com.tcs.loanms.repositories;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.tcs.loanms.entity.Loan;
import com.tcs.loanms.exceptions.LoanNotFoundException;

@Repository
public class LoanRepository {
	public Map<Long,Loan> loanList=new HashMap<>();
	public Long count=0L;
	
	public Loan saveLoan(Loan loan) {
		loan.setLoanId(++count);
		loanList.put(loan.getLoanId(), loan);
		return loan;
	}
	
	public List<Loan> viewAllLoans(){
		return new ArrayList<Loan>(loanList.values());
	}
	
	public Loan getLoanByLoanId(Long id) {
		Loan loan = loanList.get(id);
		if (loan == null) {
			throw new LoanNotFoundException("Loan does not exist"); 
		}
		return loan;
	}
	
	public boolean updateLoanStatusByLoanId(String applicantName) {
		return loanList.values().stream()
				                .anyMatch(loan->loan.getApplicantName().equalsIgnoreCase(applicantName) 
				                		&& loan.getLoanStatus().equals("PENDING"));
	}
}
