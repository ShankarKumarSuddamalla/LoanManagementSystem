package com.tcs.loanms.exceptions;

public class DuplicateLoanApplicationException extends RuntimeException{
	public DuplicateLoanApplicationException(String msg) {
		super(msg);
	}
}
