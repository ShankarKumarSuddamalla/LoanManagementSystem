package com.tcs.loanms.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(InvalidLoanAmountException.class)
	
	public ResponseEntity<ErrorResponse> handleInvalidLoanAmountException(InvalidLoanAmountException ex){
		ErrorResponse error=new ErrorResponse("Inavlid Loan Amount Exception",ex.getMessage());
		return new ResponseEntity(error,HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(LoanNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleLoanNotFoundException(LoanNotFoundException ex){
		ErrorResponse error1=new ErrorResponse("LoanNotFoundException",ex.getMessage());
		return new ResponseEntity(error1,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(DuplicateLoanApplicationException.class)
	public ResponseEntity<ErrorResponse> handleDuplicateLoanApplicationException(DuplicateLoanApplicationException ex){
		ErrorResponse error=new ErrorResponse("Duplicate Loan Application Exception",ex.getMessage());
		return new ResponseEntity(error,HttpStatus.NOT_ACCEPTABLE);
	}
	
}
